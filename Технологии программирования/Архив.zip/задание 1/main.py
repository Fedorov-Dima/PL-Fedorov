# ЗАДАНИЕ
#
# У вас есть результат распознавания речи телефонного разговора, где каналы разделены:
#   • Левый канал — оператор (файл f1.json),
#   • Правый канал — клиент (файл f2.json).
#
# Каждый канал лежит в отдельном JSON-файле со списком фрагментов:
# [
#   { "start": 2.03, "end": 2.63, "text": "Алло," },
#   { "start": 2.63, "end": 3.03, "text": "Елен," },
#   { "start": 3.17, "end": 3.67, "text": "здравствуйте." }
# ]
#
# Нужно: прочитать оба файла, собрать единый поток реплик с указанием говорящего
# и склеить соседние фрагменты одного говорящего в полноценные предложения. Результат сохранить в файл result.json


from typing import Dict, List, Union


def combine_calls(first_call: List[Dict[str, Union[str, int]]],
                  second_call: List[Dict[str, Union[str, int]]]) -> List[Dict[str, str]]:
    """
    Объединения каналов транскрибации звонков
    :param first_call: левый канал (оператор)
    :param second_call: правый канал (клиент)
    :return: итоговая транскрибация диалога
    """

    # Тут писать код <-
    pass

def get_calls(path: str = r"./f1.json") -> List[Dict[str, Union[str, int]]]:
    """
    Получение транскрибации разговора из файла
    :param path: путь к файлу
    :return: диалог участника
    """
    # Тут писать код <-
    pass

def save_result(path: str = r"./result.json") -> None:
    """
    Сохранение результатов в файл
    :param path:
    :return:
    """

def main():
    """
    Основная функция
    :return: None
    """
    # Тут писать код <-
    get_calls()

if __name__ == '__main__':
    main()