#  ЗАДАНИЕ
#
#  Вы аналитик внутри компании в отделе продаж. Вам нужно написать программу, которая принимаем данные о продажах за месяц (функция get_data) и формирует отчет, состоящий из:
#  1) total — общая выручка
#  2) most_expensive — самый дорогой товар по price
#  3) most_profitable — товар с максимальной выручкой, по сумме всех его строк
#  4) most_sold — товар с наибольшим суммарным quantity (с учётом дублей)
#  5) revenue_by_category — словарь: категория -> выручка, кол-во продаж
#  6) top_category — категория с максимальной выручкой
#
#  Отчет сохранить в файл (тип файла и вид отчета на ваш выбор)

from typing import List, Dict, Union


def get_data() -> List[Dict[str, Union[str, int]]]:
    """Получение данных"""
    return [
        {"item": "Телефон X",   "category": "Электроника", "price": 25000, "quantity": 2},
        {"item": "Ноутбук Z",   "category": "Электроника", "price": 70000, "quantity": 1},
        {"item": "Планшет M",   "category": "Электроника", "price": 40000, "quantity": 3},
        {"item": "Наушники S",  "category": "Аксессуары",  "price": 3000,  "quantity": 5},
        {"item": "Чехол T",     "category": "Аксессуары",  "price": 500,   "quantity": 10},
        {"item": "Клавиатура K","category": "Периферия",   "price": 2000,  "quantity": 4},
        {"item": "Мышь L",      "category": "Периферия",   "price": 1500,  "quantity": 6},
        {"item": "Чехол T",     "category": "Аксессуары",  "price": 500,   "quantity": 7},
        {"item": "Наушники S",  "category": "Аксессуары",  "price": 3000,  "quantity": 2},
    ]

def generation_report(data: List[Dict[str, Union[str, int]]]) -> str:
    """
    Формирование текстового отчета
    :param data: статистика продаж
    :return: отчет в текстовой форме
    """
    pass


def save_report(data: str, path: str = r"./result.txt") -> None:
    """
    Сохранение отчета в файле
    :param data: отчет
    :param path: путь к файлу
    :return: None
    """
    pass

def main():
    pass


if __name__ == "__main__":
    main()